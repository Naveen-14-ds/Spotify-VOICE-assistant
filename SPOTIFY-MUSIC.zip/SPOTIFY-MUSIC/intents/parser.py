"""
Natural Language Parser for Music Commands
Extracts intent, song, and artist from voice commands
"""

import re
from typing import Dict, Optional


def remove_filler_words(text: str) -> str:
    """Remove polite/filler words from command"""
    fillers = [
        'please', 'can you', 'could you', 'would you', 'i want',
        'i would like', 'i need', 'you to', 'to play', 'for me',
        'just', 'maybe', 'kind of', 'sort of', 'the', 'song', 'track'
    ]
    
    cleaned = text.lower()
    for filler in fillers:
        cleaned = cleaned.replace(filler, '')
    
    cleaned = ' '.join(cleaned.split())
    return cleaned.strip()


def extract_song_artist(text: str) -> Dict[str, Optional[str]]:
    """Extract song name and artist from play commands"""
    result = {"song": None, "artist": None}
    
    # Pattern: "play [song] by [artist]"
    by_pattern = r'play\s+(.+?)\s+by\s+(.+)$'
    match = re.search(by_pattern, text, re.IGNORECASE)
    
    if match:
        result["song"] = match.group(1).strip()
        result["artist"] = match.group(2).strip()
        return result
    
    # Pattern: "play [song]" (no artist)
    play_pattern = r'play\s+(.+)$'
    match = re.search(play_pattern, text, re.IGNORECASE)
    
    if match:
        song_name = match.group(1).strip()
        # Remove common suffixes
        suffixes = [' song', ' track', ' music', ' now']
        for suffix in suffixes:
            if song_name.endswith(suffix):
                song_name = song_name[:-len(suffix)]
        result["song"] = song_name.strip()
    
    return result


def detect_intent(text: str) -> str:
    """Detect the user's intent from command text"""
    text = text.lower().strip()
    
    # Play intents
    play_keywords = ['play', 'start', 'begin', 'put on']
    if any(keyword in text for keyword in play_keywords):
        return "play"
    
    # Pause intents
    pause_keywords = ['pause', 'hold', 'wait']
    if any(keyword in text for keyword in pause_keywords):
        return "pause"
    
    # Stop intents
    stop_keywords = ['stop', 'end', 'quit', 'shut up', 'turn off']
    if any(keyword in text for keyword in stop_keywords):
        return "stop"
    
    # Next intents
    next_keywords = ['next', 'skip', 'forward', 'advance']
    if any(keyword in text for keyword in next_keywords):
        return "next"
    
    # Previous intents
    prev_keywords = ['previous', 'back', 'last', 'before', 'earlier']
    if any(keyword in text for keyword in prev_keywords):
        return "previous"
    
    return "unknown"


def parse_command(text: str) -> Dict:
    """Main parsing function"""
    cleaned = remove_filler_words(text)
    intent = detect_intent(cleaned)
    
    result = {
        "intent": intent,
        "song": None,
        "artist": None,
        "original_text": text
    }
    
    if intent == "play":
        extracted = extract_song_artist(cleaned)
        result.update(extracted)
    
    return result