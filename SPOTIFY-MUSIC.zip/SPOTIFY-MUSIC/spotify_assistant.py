#!/usr/bin/env python3
"""
Spotify Voice Assistant - Full Playback Control
Auto-plays, pauses, skips, and queues songs
"""

import spotipy
from spotipy.oauth2 import SpotifyOAuth
from flask import Flask, render_template_string, request, jsonify
import json
import os
from intents.parser import parse_command

# ============== SPOTIFY CONFIGURATION ==============
# Get these from https://developer.spotify.com/dashboard
SPOTIFY_CLIENT_ID = "44e232875d4b40df93eab65a6da6cd70"
SPOTIFY_CLIENT_SECRET = "cbfbc53c436948be9b7d474b895ae795"
SPOTIFY_REDIRECT_URI = "http://127.0.0.1:8000/callback"

app = Flask(__name__)

class SpotifyController:
    def __init__(self):
        self.sp = None
        self.authenticated = False
        self.current_track = None
        
    def authenticate(self):
        """Authenticate with Spotify"""
        if self.authenticated and self.sp:
            return True
            
        try:
            self.sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
                client_id=SPOTIFY_CLIENT_ID,
                client_secret=SPOTIFY_CLIENT_SECRET,
                redirect_uri=SPOTIFY_REDIRECT_URI,
                scope="user-read-playback-state,user-modify-playback-state,user-read-currently-playing,streaming,app-remote-control,user-read-private",
                cache_path=".spotify_cache"
            ))
            self.authenticated = True
            return True
        except Exception as e:
            print(f"Auth error: {e}")
            return False
    
    def search_and_play(self, song, artist=None):
        """Search and automatically play song"""
        if not self.authenticated:
            return "Not authenticated with Spotify", None
        
        try:
            query = f"{song} {artist}" if artist else song
            results = self.sp.search(q=query, type='track', limit=1)
            
            if not results['tracks']['items']:
                return f"Could not find: {query}", None
            
            track = results['tracks']['items'][0]
            track_uri = track['uri']
            track_name = track['name']
            track_artist = track['artists'][0]['name']
            
            # Get available devices
            devices = self.sp.devices()
            if not devices['devices']:
                return "No active Spotify device found. Open Spotify on your phone/PC first.", None
            
            # Find active device or use first available
            device_id = None
            for device in devices['devices']:
                if device.get('is_active'):
                    device_id = device['id']
                    break
            
            if not device_id:
                device_id = devices['devices'][0]['id']
            
            # Start playback automatically
            self.sp.start_playback(device_id=device_id, uris=[track_uri])
            self.current_track = f"{track_name} by {track_artist}"
            
            return f"Playing {track_name} by {track_artist}", self.current_track
            
        except Exception as e:
            return f"Error: {str(e)}", None
    
    def pause(self):
        """Pause playback"""
        if not self.authenticated:
            return "Not authenticated"
        try:
            self.sp.pause_playback()
            return "Music paused"
        except Exception as e:
            return f"Pause failed: {e}"
    
    def resume(self):
        """Resume playback"""
        if not self.authenticated:
            return "Not authenticated"
        try:
            self.sp.start_playback()
            return "Music resumed"
        except Exception as e:
            return f"Resume failed: {e}"
    
    def next_track(self):
        """Skip to next"""
        if not self.authenticated:
            return "Not authenticated"
        try:
            self.sp.next_track()
            return "Skipped to next song"
        except Exception as e:
            return f"Skip failed: {e}"
    
    def previous_track(self):
        """Go to previous"""
        if not self.authenticated:
            return "Not authenticated"
        try:
            self.sp.previous_track()
            return "Went back to previous song"
        except Exception as e:
            return f"Previous failed: {e}"
    
    def get_current_track(self):
        """Get currently playing track"""
        if not self.authenticated:
            return "Not connected"
        try:
            playback = self.sp.current_playback()
            if playback and playback.get('item'):
                track_name = playback['item']['name']
                artist_name = playback['item']['artists'][0]['name']
                is_playing = playback.get('is_playing', False)
                status = "▶️" if is_playing else "⏸️"
                return f"{status} {track_name} by {artist_name}"
            return "Nothing playing"
        except:
            return "Nothing playing"

# Initialize controller
controller = SpotifyController()

# ============== HTML INTERFACE ==============
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>🎵 Spotify Voice Assistant</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: linear-gradient(135deg, #121212 0%, #1a1a2e 50%, #16213e 100%);
            min-height: 100vh;
            color: white;
        }
        .container { max-width: 900px; margin: 0 auto; padding: 30px 20px; }
        
        /* Header */
        .header { text-align: center; margin-bottom: 30px; }
        h1 {
            font-size: 2.8em;
            font-weight: 800;
            background: linear-gradient(90deg, #1db954, #1ed760, #1db954);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: shine 3s linear infinite;
            margin-bottom: 10px;
        }
        @keyframes shine {
            to { background-position: 200% center; }
        }
        .subtitle { color: #888; font-size: 1.1em; }
        
        /* Auth Status */
        .auth-card {
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 25px;
            margin: 25px 0;
            border: 1px solid rgba(255,255,255,0.1);
        }
        .auth-success {
            background: linear-gradient(135deg, #1db95420, #1ed76020);
            border: 2px solid #1db954;
        }
        .auth-pending {
            background: linear-gradient(135deg, #f39c1220, #e67e2220);
            border: 2px solid #f39c12;
        }
        .status-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 20px;
            border-radius: 25px;
            font-weight: 600;
            margin-bottom: 15px;
        }
        .badge-success { background: #1db954; color: #000; }
        .badge-pending { background: #f39c12; color: #000; }
        
        /* Now Playing */
        .now-playing {
            background: linear-gradient(135deg, #1db95415, #1ed76015);
            border: 2px solid #1db954;
            border-radius: 20px;
            padding: 25px;
            margin: 25px 0;
            text-align: center;
        }
        .now-playing h3 {
            color: #1ed760;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 2px;
            margin-bottom: 10px;
        }
        .track-name {
            font-size: 1.5em;
            font-weight: 700;
            margin-bottom: 5px;
        }
        .track-artist {
            color: #888;
            font-size: 1.1em;
        }
        
        /* Controls */
        .controls {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin: 25px 0;
            flex-wrap: wrap;
        }
        .control-btn {
            padding: 15px 25px;
            border: none;
            border-radius: 50px;
            background: #282828;
            color: white;
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 8px;
            font-weight: 600;
        }
        .control-btn:hover {
            background: #1db954;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(29,185,84,0.3);
        }
        .control-btn.primary {
            background: #1db954;
            color: #000;
            padding: 18px 35px;
            font-size: 1.1em;
        }
        .control-btn.primary:hover {
            background: #1ed760;
        }
        
        /* Voice Section */
        .voice-section {
            text-align: center;
            margin: 40px 0;
        }
        .mic-container {
            position: relative;
            display: inline-block;
        }
        .mic-button {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: none;
            background: linear-gradient(135deg, #1db954 0%, #169c46 100%);
            color: white;
            font-size: 50px;
            cursor: pointer;
            box-shadow: 0 15px 35px rgba(29, 185, 84, 0.4);
            transition: all 0.3s ease;
            position: relative;
            z-index: 2;
        }
        .mic-button:hover {
            transform: scale(1.1);
            box-shadow: 0 20px 40px rgba(29, 185, 84, 0.5);
        }
        .mic-button.listening {
            background: linear-gradient(135deg, #e74c3c 0%, #c0392b 100%);
            animation: pulse-ring 1.5s infinite;
        }
        @keyframes pulse-ring {
            0% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.7); }
            70% { box-shadow: 0 0 0 30px rgba(231, 76, 60, 0); }
            100% { box-shadow: 0 0 0 0 rgba(231, 76, 60, 0); }
        }
        .mic-ring {
            position: absolute;
            top: -10px;
            left: -10px;
            right: -10px;
            bottom: -10px;
            border-radius: 50%;
            border: 3px solid #1db954;
            opacity: 0;
            transition: all 0.3s;
        }
        .mic-button.listening + .mic-ring {
            opacity: 1;
            animation: rotate 2s linear infinite;
        }
        @keyframes rotate {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        /* Status & Hints */
        .status-box {
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            padding: 20px;
            margin: 25px 0;
            font-size: 1.1em;
            min-height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .command-hints {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            justify-content: center;
            margin: 20px 0;
        }
        .hint-tag {
            background: rgba(29,185,84,0.15);
            border: 1px solid #1db954;
            color: #1ed760;
            padding: 10px 18px;
            border-radius: 25px;
            font-size: 0.9em;
            cursor: pointer;
            transition: all 0.3s;
        }
        .hint-tag:hover {
            background: #1db954;
            color: #000;
        }
        
        /* Chat History */
        .chat-section {
            background: rgba(0,0,0,0.2);
            border-radius: 20px;
            padding: 25px;
            margin-top: 30px;
        }
        .chat-header {
            color: #888;
            text-align: center;
            margin-bottom: 15px;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 2px;
        }
        .chat-messages {
            max-height: 300px;
            overflow-y: auto;
        }
        .message {
            margin: 12px 0;
            padding: 15px 20px;
            border-radius: 18px;
            max-width: 80%;
            animation: slideIn 0.3s ease;
        }
        @keyframes slideIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .user-message {
            background: linear-gradient(135deg, #1db954, #1ed760);
            color: #000;
            margin-left: auto;
            font-weight: 500;
        }
        .bot-message {
            background: #282828;
            margin-right: auto;
        }
        
        /* Setup Instructions */
        .setup-steps {
            text-align: left;
            margin-top: 15px;
        }
        .setup-steps ol {
            margin-left: 20px;
            line-height: 2;
        }
        .setup-steps a {
            color: #1ed760;
            text-decoration: none;
        }
        .setup-steps a:hover {
            text-decoration: underline;
        }
        code {
            background: #000;
            padding: 3px 8px;
            border-radius: 5px;
            font-family: 'Courier New', monospace;
            color: #1ed760;
        }
        
        /* Scrollbar */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #1a1a2e;
        }
        ::-webkit-scrollbar-thumb {
            background: #1db954;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🎵 Spotify Voice Assistant</h1>
            <p class="subtitle">Full voice control - Play, Pause, Skip automatically</p>
        </div>
        
        {% if not authenticated %}
        <div class="auth-card auth-pending">
            <div class="status-badge badge-pending">⚠️ Spotify Not Connected</div>
            <h3 style="margin-bottom: 15px;">Setup Required (One-time):</h3>
            <div class="setup-steps">
                <ol>
                    <li>Go to <a href="https://developer.spotify.com/dashboard" target="_blank">Spotify Developer Dashboard</a></li>
                    <li>Click "Create App" → Name: "Voice Assistant" → Any description</li>
                    <li>In Redirect URIs, add: <code>http://localhost:8888/callback</code></li>
                    <li>Copy <strong>Client ID</strong> and <strong>Client Secret</strong></li>
                    <li>Paste them in <code>spotify_assistant.py</code> (lines 14-15)</li>
                    <li>Restart this app and refresh this page</li>
                </ol>
            </div>
        </div>
        {% else %}
        <div class="auth-card auth-success">
            <div class="status-badge badge-success">✅ Connected to Spotify</div>
        </div>
        
        <div class="now-playing" id="nowPlaying">
            <h3>🎧 Now Playing</h3>
            <div class="track-name" id="trackName">Nothing playing</div>
            <div class="track-artist" id="trackArtist">Open Spotify on your device</div>
        </div>
        
        <div class="controls">
            <button class="control-btn" onclick="sendCommand('previous')">⏮️ Previous</button>
            <button class="control-btn primary" onclick="sendCommand('pause')">⏸️ Pause</button>
            <button class="control-btn primary" onclick="sendCommand('play')">▶️ Play</button>
            <button class="control-btn" onclick="sendCommand('next')">⏭️ Next</button>
        </div>
        {% endif %}
        
        <div class="voice-section">
            <div class="command-hints">
                <span class="hint-tag" onclick="speakHint('Play Believer by Imagine Dragons')">"Play Believer by Imagine Dragons"</span>
                <span class="hint-tag" onclick="speakHint('Play Shape of You')">"Play Shape of You"</span>
                <span class="hint-tag" onclick="speakHint('Pause')">"Pause"</span>
                <span class="hint-tag" onclick="speakHint('Next song')">"Next song"</span>
                <span class="hint-tag" onclick="speakHint('Previous')">"Previous"</span>
            </div>
            
            <div class="mic-container">
                <button class="mic-button" id="micBtn" onclick="toggleListening()">🎤</button>
                <div class="mic-ring"></div>
            </div>
            
            <div class="status-box" id="status">Click microphone and speak your command</div>
        </div>
        
        <div class="chat-section">
            <div class="chat-header">💬 Conversation History</div>
            <div class="chat-messages" id="chatHistory">
                <div style="text-align: center; color: #666; padding: 20px;">No commands yet</div>
            </div>
        </div>
    </div>

    <script>
        let recognition;
        let isListening = false;
        let messageCount = 0;
        
        // Initialize Speech Recognition
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = false;
            recognition.lang = 'en-US';
            
            recognition.onstart = function() {
                isListening = true;
                document.getElementById('micBtn').classList.add('listening');
                updateStatus('🔴 Listening... Speak now', 'listening');
            };
            
            recognition.onend = function() {
                isListening = false;
                document.getElementById('micBtn').classList.remove('listening');
                updateStatus('Click microphone for next command', 'ready');
            };
            
            recognition.onresult = function(event) {
                const command = event.results[0][0].transcript;
                addMessage(command, 'user');
                processCommand(command);
            };
            
            recognition.onerror = function(event) {
                updateStatus('❌ Error: ' + event.error, 'error');
                isListening = false;
                document.getElementById('micBtn').classList.remove('listening');
            };
        } else {
            updateStatus('❌ Voice not supported. Use Chrome/Edge.', 'error');
        }
        
        function toggleListening() {
            if (!recognition) {
                alert('Please use Chrome or Edge browser for voice support');
                return;
            }
            if (isListening) {
                recognition.stop();
            } else {
                recognition.start();
            }
        }
        
        function speakHint(text) {
            updateStatus('🎤 ' + text, 'ready');
        }
        
        function updateStatus(text, type) {
            const statusEl = document.getElementById('status');
            statusEl.textContent = text;
            statusEl.style.background = type === 'listening' ? 'rgba(231,76,60,0.2)' : 
                                       type === 'error' ? 'rgba(231,76,60,0.2)' : 
                                       'rgba(255,255,255,0.05)';
            statusEl.style.border = type === 'listening' ? '1px solid #e74c3c' : 
                                   type === 'error' ? '1px solid #e74c3c' : 
                                   '1px solid rgba(255,255,255,0.1)';
        }
        
        function addMessage(text, type) {
            const chat = document.getElementById('chatHistory');
            if (messageCount === 0) chat.innerHTML = '';
            
            const div = document.createElement('div');
            div.className = 'message ' + (type === 'user' ? 'user-message' : 'bot-message');
            div.textContent = (type === 'user' ? '🗣️ ' : '🤖 ') + text;
            chat.appendChild(div);
            chat.scrollTop = chat.scrollHeight;
            messageCount++;
        }
        
        function processCommand(command) {
            updateStatus('🔄 Processing: "' + command + '"', 'processing');
            
            fetch('/process', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({command: command})
            })
            .then(r => r.json())
            .then(data => {
                addMessage(data.response, 'bot');
                updateStatus('✅ ' + data.response, 'success');
                
                // Update now playing if track info available
                if (data.track && data.track !== 'Not connected') {
                    const parts = data.track.replace('▶️ ', '').replace('⏸️ ', '').split(' by ');
                    document.getElementById('trackName').textContent = parts[0] || 'Unknown';
                    document.getElementById('trackArtist').textContent = parts[1] ? 'by ' + parts[1] : '';
                }
            })
            .catch(e => {
                updateStatus('❌ Failed to process command', 'error');
            });
        }
        
        function sendCommand(cmd) {
            processCommand(cmd);
        }
        
        // Auto-update current track
        {% if authenticated %}
        setInterval(() => {
            fetch('/current').then(r => r.json()).then(data => {
                if (data.track && data.track !== 'Not connected' && data.track !== 'Nothing playing') {
                    const parts = data.track.replace('▶️ ', '').replace('⏸️ ', '').split(' by ');
                    document.getElementById('trackName').textContent = parts[0] || 'Unknown';
                    document.getElementById('trackArtist').textContent = parts[1] ? 'by ' + parts[1] : '';
                }
            });
        }, 2000);
        {% endif %}
    </script>
</body>
</html>
"""

# ============== ROUTES ==============
@app.route('/')
def index():
    auth = controller.authenticate()
    return render_template_string(HTML_TEMPLATE, authenticated=auth)

@app.route('/process', methods=['POST'])
def process():
    data = request.get_json()
    command_text = data.get('command', '').lower()
    
    # Parse the command
    parsed = parse_command(command_text)
    intent = parsed.get('intent')
    song = parsed.get('song')
    artist = parsed.get('artist')
    
    response_text = ""
    current_track = None
    
    # Execute based on intent
    if intent == 'play':
        if not song:
            response_text = "Please tell me the song name"
        else:
            response_text, current_track = controller.search_and_play(song, artist)
            
    elif intent == 'pause':
        response_text = controller.pause()
        
    elif intent == 'stop':
        response_text = controller.pause()
        
    elif intent == 'next':
        response_text = controller.next_track()
        
    elif intent == 'previous':
        response_text = controller.previous_track()
        
    else:
        response_text = "I didn't understand. Try 'play [song]', 'pause', 'next', or 'previous'"
    
    # Get updated track info
    current_track = controller.get_current_track()
    
    return jsonify({
        "response": response_text,
        "track": current_track
    })

@app.route('/current')
def current():
    track = controller.get_current_track()
    return jsonify({"track": track})

# ============== MAIN ==============
if __name__ == '__main__':
    print("=" * 70)
    print("🎵 SPOTIFY VOICE ASSISTANT")
    print("=" * 70)
    print("SETUP INSTRUCTIONS:")
    print("1. Go to: https://developer.spotify.com/dashboard")
    print("2. Create an app (any name)")
    print("3. Add Redirect URI: http://localhost:8888/callback")
    print("4. Copy Client ID and Secret to lines 14-15 in this file")
    print("5. Save and run: python spotify_assistant.py")
    print("6. Open: http://localhost:5000")
    print("=" * 70)
    print("\n⚠️  IMPORTANT: Make sure SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET")
    print("    are set in the code before running!")
    print("=" * 70)
    
    # Check if credentials are set
    if SPOTIFY_CLIENT_ID == "YOUR_CLIENT_ID_HERE" or SPOTIFY_CLIENT_SECRET == "YOUR_CLIENT_SECRET_HERE":
        print("\n❌ ERROR: You need to set your Spotify credentials first!")
        print("   Edit the file and replace YOUR_CLIENT_ID_HERE and YOUR_CLIENT_SECRET_HERE")
    else:
        print("\n✅ Starting server...")
        app.run(debug=True, host='0.0.0.0', port=5000)